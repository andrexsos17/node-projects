
exports.handler = async (event, context) => {
  console.log(`Event: `, event);

  try {
    if(event.param1 === 1){
        throw new BaseError("soy un error",500,"soy errro2",false);
    }else{
        return {
            code: 400,
            message: {
                msg:"soy un error",
                statusCode: 400
            },
          };
    }

  } catch (err) {
    console.log(`Error On handler: `, err);
    result = {
        code: 500,
        message: {
            msg:"soy un error",
            statusCode: 500
        },
      };
  }
  return result;
};

class BaseError extends Error {
    name: string;
    httpCode: HttpStatusCode;
    isOperational: boolean;
    
    constructor(name: string, httpCode: HttpStatusCode, description: string, isOperational: boolean) {
      super(description);
      Object.setPrototypeOf(this, new.target.prototype);
    
      this.name = name;
      this.httpCode = httpCode;
      this.isOperational = isOperational;
    
      Error.captureStackTrace(this);
    }
}